export interface PersistedVideoInfo {
  type: 'url' | 'file';
  url: string;
  name: string;
  description?: string;
  size?: number;
  uploadedAt: string;
  isDefault?: boolean;
}

export const DEFAULT_TEAM_VIDEO: PersistedVideoInfo = {
  type: 'url',
  url: 'https://www.youtube.com/watch?v=_HHZWmEm9K4',
  name: '【小組實測影片】台北捷運孕婦負重體驗與讓座實測紀錄',
  description: '體驗者配戴 6.5kg 負重裝置搭乘台北捷運淡水信義線，實測車廂顛簸站立、乘客發現與友善讓座互動全紀錄。',
  uploadedAt: '2026-10-17T08:00:00.000Z',
  isDefault: true,
};
